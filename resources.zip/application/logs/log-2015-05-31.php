<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-05-31 08:56:42 --> Config Class Initialized
INFO - 2015-05-31 08:56:42 --> Hooks Class Initialized
DEBUG - 2015-05-31 08:56:42 --> UTF-8 Support Enabled
INFO - 2015-05-31 08:56:42 --> Utf8 Class Initialized
INFO - 2015-05-31 08:56:42 --> URI Class Initialized
DEBUG - 2015-05-31 08:56:42 --> No URI present. Default controller set.
INFO - 2015-05-31 08:56:42 --> Router Class Initialized
INFO - 2015-05-31 08:56:42 --> Output Class Initialized
INFO - 2015-05-31 08:56:42 --> Security Class Initialized
INFO - 2015-05-31 08:56:42 --> CRSF cookie sent
DEBUG - 2015-05-31 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-05-31 08:56:42 --> Input Class Initialized
INFO - 2015-05-31 08:56:42 --> Language Class Initialized
INFO - 2015-05-31 08:56:42 --> Language Class Initialized
INFO - 2015-05-31 08:56:42 --> Config Class Initialized
INFO - 2015-05-31 08:56:42 --> Loader Class Initialized
INFO - 2015-05-31 08:56:42 --> Helper loaded: url_helper
INFO - 2015-05-31 08:56:42 --> Helper loaded: date_helper
INFO - 2015-05-31 08:56:42 --> Helper loaded: form_helper
INFO - 2015-05-31 08:56:42 --> Helper loaded: html_helper
INFO - 2015-05-31 08:56:42 --> Helper loaded: string_helper
INFO - 2015-05-31 08:56:42 --> Database Driver Class Initialized
INFO - 2015-05-31 08:56:42 --> Session: Class initialized using 'database' driver.
INFO - 2015-05-31 08:56:42 --> Controller Class Initialized
INFO - 2015-05-31 08:56:42 --> Model Class Initialized
DEBUG - 2015-05-31 08:56:42 --> File loaded: D:\localhost\github_projects\url_shortner\url_shortner\application\modules/public_page/models/Shorten_model.php
DEBUG - 2015-05-31 08:56:42 --> File loaded: D:\localhost\github_projects\url_shortner\url_shortner\application\modules/public_page/views/home_page.php
DEBUG - 2015-05-31 08:56:42 --> File loaded: D:\localhost\github_projects\url_shortner\url_shortner\application\views\templates/index_page.php
INFO - 2015-05-31 08:56:42 --> Final output sent to browser
DEBUG - 2015-05-31 08:56:42 --> Total execution time: 0.0990
