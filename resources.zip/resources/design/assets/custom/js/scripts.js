$(document).ready(function(){

	$("body").height(screen.height);

});